/*
 * main.c - NetGuard entry point and CLI interface
 *
 * NetGuard: Local Network Privacy Utility
 *
 * Provides an interactive menu for managing firewall rules, trusted devices,
 * and network privacy settings. Also supports command-line arguments for
 * scripting and automation.
 *
 * Must be run as root (sudo) for firewall management.
 *
 * Usage:
 *   sudo netguard [-c config_file]
 *   sudo netguard --apply
 *   sudo netguard --strict
 *   sudo netguard --clear
 *   sudo netguard --status
 */

#include "netguard.h"
#include "config.h"
#include "firewall.h"
#include "logger.h"
#include "utils.h"
#include <signal.h>
#include <unistd.h>
#include <getopt.h>

/* ───────────────────────── Globals ──────────────────────────────────── */

static netguard_config_t g_config;
static volatile sig_atomic_t g_running = 1;

/* ───────────────────────── Signal Handler ───────────────────────────── */

/*
 * handle_signal - Graceful shutdown on SIGINT/SIGTERM.
 * Sets g_running to 0 so the main loop exits cleanly.
 */
static void handle_signal(int sig)
{
    (void)sig;
    g_running = 0;
}

static void setup_signals(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGINT,  &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
}

/* ───────────────────────── Banner ───────────────────────────────────── */

static void print_banner(void)
{
    printf("\n");
    printf("  ╔═══════════════════════════════════════════════╗\n");
    printf("  ║   NetGuard v%s                             ║\n", NETGUARD_VERSION);
    printf("  ║   Local Network Privacy Utility               ║\n");
    printf("  ║   Defensive firewall management tool           ║\n");
    printf("  ╚═══════════════════════════════════════════════╝\n");
    printf("  Backend: %s\n\n", firewall_backend_name());
}

/* ───────────────────────── CLI Menu ─────────────────────────────────── */

static void print_menu(void)
{
    printf("  ┌─────────────────────────────────┐\n");
    printf("  │         NetGuard Menu            │\n");
    printf("  ├─────────────────────────────────┤\n");
    printf("  │  1. Add trusted device           │\n");
    printf("  │  2. Remove trusted device         │\n");
    printf("  │  3. Show active rules             │\n");
    printf("  │  4. Enable STRICT local-only mode │\n");
    printf("  │  5. Enable NORMAL mode            │\n");
    printf("  │  6. Apply firewall rules          │\n");
    printf("  │  7. Clear all rules               │\n");
    printf("  │  8. Check network status          │\n");
    printf("  │  9. Export logs                    │\n");
    printf("  │ 10. Show configuration            │\n");
    printf("  │  0. Exit                          │\n");
    printf("  └─────────────────────────────────┘\n");
    printf("  Choice: ");
}

/*
 * read_line - Safely read a line from stdin into buf.
 * Strips trailing newline. Returns false on EOF or error.
 */
static bool read_line(char *buf, size_t len)
{
    if (!fgets(buf, (int)len, stdin))
        return false;

    size_t slen = strlen(buf);
    while (slen > 0 && (buf[slen - 1] == '\n' || buf[slen - 1] == '\r'))
        buf[--slen] = '\0';

    return true;
}

/* ── Menu action handlers ─────────────────────────────────────────────── */

static void action_add_trusted(void)
{
    char ip[MAX_IP_LEN];
    printf("  Enter IPv4 address to trust: ");
    if (!read_line(ip, sizeof(ip))) return;

    utils_sanitize_input(ip, sizeof(ip));

    int rc = config_add_trusted_ip(&g_config, ip);
    if (rc == NG_SUCCESS) {
        config_save(&g_config);
        logger_log(LOG_INFO, ip, 0, "Trusted device added");
        printf("  [OK] Added %s to trusted list.\n", ip);
        printf("  Run option 6 to apply updated rules.\n");
    } else if (rc == NG_EINVAL) {
        printf("  [ERROR] Invalid IPv4 address: %s\n", ip);
    } else {
        printf("  [ERROR] Could not add device (list may be full).\n");
    }
}

static void action_remove_trusted(void)
{
    if (g_config.trusted_ip_count == 0) {
        printf("  No trusted devices configured.\n");
        return;
    }

    printf("  Current trusted devices:\n");
    for (int i = 0; i < g_config.trusted_ip_count; i++)
        printf("    %d. %s\n", i + 1, g_config.trusted_ips[i]);

    char ip[MAX_IP_LEN];
    printf("  Enter IP to remove: ");
    if (!read_line(ip, sizeof(ip))) return;

    utils_sanitize_input(ip, sizeof(ip));

    int rc = config_remove_trusted_ip(&g_config, ip);
    if (rc == NG_SUCCESS) {
        config_save(&g_config);
        logger_log(LOG_INFO, ip, 0, "Trusted device removed");
        printf("  [OK] Removed %s from trusted list.\n", ip);
        printf("  Run option 6 to apply updated rules.\n");
    } else if (rc == NG_ENOTFOUND) {
        printf("  [ERROR] IP %s not found in trusted list.\n", ip);
    } else {
        printf("  [ERROR] Invalid input.\n");
    }
}

static void action_show_rules(void)
{
    firewall_show_rules();
}

static void action_enable_strict(void)
{
    g_config.mode = MODE_STRICT;
    config_save(&g_config);
    logger_log(LOG_INFO, NULL, 0, "Switched to STRICT mode");
    printf("  [OK] Mode set to STRICT (localhost only).\n");

    /* Auto-apply */
    firewall_apply_rules(&g_config);
}

static void action_enable_normal(void)
{
    g_config.mode = MODE_NORMAL;
    config_save(&g_config);
    logger_log(LOG_INFO, NULL, 0, "Switched to NORMAL mode");
    printf("  [OK] Mode set to NORMAL.\n");

    /* Auto-apply */
    firewall_apply_rules(&g_config);
}

static void action_apply_rules(void)
{
    if (firewall_apply_rules(&g_config) == NG_SUCCESS) {
        logger_log(LOG_INFO, NULL, 0, "Rules applied from menu");
    }
}

static void action_clear_rules(void)
{
    firewall_clear_rules();
}

static void action_check_network(void)
{
    char ssid[MAX_SSID_LEN];
    printf("\n  --- Network Status ---\n");

    if (utils_get_current_ssid(ssid, sizeof(ssid)) == NG_SUCCESS) {
        printf("  Current WiFi SSID: %s\n", ssid);
    } else {
        printf("  Current WiFi SSID: (unknown / not connected)\n");
    }

    bool trusted = utils_is_trusted_network(
        g_config.trusted_networks, g_config.trusted_network_count);

    if (trusted) {
        printf("  Network status:    TRUSTED\n");
        printf("  Recommendation:    Normal mode is safe.\n");
    } else {
        printf("  Network status:    UNTRUSTED / UNKNOWN\n");
        printf("  Recommendation:    Enable STRICT mode (option 4).\n");

        /* Auto-switch to strict if not already */
        if (g_config.mode != MODE_STRICT) {
            printf("\n  WARNING: You are on an untrusted network in NORMAL mode.\n");
            printf("  Consider switching to STRICT mode for maximum protection.\n");
            logger_log(LOG_WARN, NULL, 0,
                       "Untrusted network detected, STRICT mode recommended");
        }
    }

    printf("  ----------------------\n\n");
}

static void action_export_logs(void)
{
    char path[MAX_PATH_LEN];
    printf("  Enter export file path: ");
    if (!read_line(path, sizeof(path))) return;

    utils_sanitize_input(path, sizeof(path));

    if (strlen(path) == 0) {
        printf("  [ERROR] Empty path.\n");
        return;
    }

    if (logger_export(path) == NG_SUCCESS) {
        printf("  [OK] Logs exported to %s\n", path);
    } else {
        printf("  [ERROR] Failed to export logs.\n");
    }
}

/* ───────────────────────── Auto Network Check ───────────────────────── */

/*
 * auto_network_check - Called at startup and can be called periodically.
 * If the device is on an untrusted network and mode is NORMAL,
 * automatically switches to STRICT mode and applies rules.
 */
static void auto_network_check(void)
{
    if (g_config.trusted_network_count == 0)
        return;  /* No trusted networks configured, skip auto-detection */

    bool trusted = utils_is_trusted_network(
        g_config.trusted_networks, g_config.trusted_network_count);

    if (!trusted && g_config.mode == MODE_NORMAL) {
        printf("\n  [AUTO] Untrusted network detected — switching to STRICT mode.\n");
        logger_log(LOG_WARN, NULL, 0,
                   "Auto-switching to STRICT mode (untrusted network)");
        g_config.mode = MODE_STRICT;
        config_save(&g_config);
        firewall_apply_rules(&g_config);
    } else if (trusted && g_config.mode == MODE_STRICT) {
        printf("\n  [AUTO] Trusted network detected — you may switch to NORMAL mode.\n");
        logger_log(LOG_INFO, NULL, 0,
                   "Trusted network detected, NORMAL mode available");
    }
}

/* ───────────────────────── Usage / Help ──────────────────────────────── */

static void print_usage(const char *progname)
{
    printf("Usage: sudo %s [OPTIONS]\n\n", progname);
    printf("Options:\n");
    printf("  -c, --config FILE   Path to config file (default: ./netguard.conf)\n");
    printf("  -a, --apply         Apply rules from config and exit\n");
    printf("  -s, --strict        Enable strict mode, apply, and exit\n");
    printf("  -n, --normal        Enable normal mode, apply, and exit\n");
    printf("  -r, --clear         Clear all NetGuard rules and exit\n");
    printf("  -S, --status        Show current status and exit\n");
    printf("  -h, --help          Show this help message\n");
    printf("  -v, --version       Show version\n");
    printf("\nInteractive mode (no action flags): launches the CLI menu.\n");
}

/* ───────────────────────── Main ─────────────────────────────────────── */

int main(int argc, char *argv[])
{
    const char *config_path = "./netguard.conf";
    bool flag_apply  = false;
    bool flag_strict = false;
    bool flag_normal = false;
    bool flag_clear  = false;
    bool flag_status = false;

    /* ── Parse command-line arguments ─────────────────────────────── */

    static struct option long_opts[] = {
        {"config",  required_argument, NULL, 'c'},
        {"apply",   no_argument,       NULL, 'a'},
        {"strict",  no_argument,       NULL, 's'},
        {"normal",  no_argument,       NULL, 'n'},
        {"clear",   no_argument,       NULL, 'r'},
        {"status",  no_argument,       NULL, 'S'},
        {"help",    no_argument,       NULL, 'h'},
        {"version", no_argument,       NULL, 'v'},
        {NULL, 0, NULL, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "c:asnrShv", long_opts, NULL)) != -1) {
        switch (opt) {
            case 'c': config_path = optarg; break;
            case 'a': flag_apply  = true;   break;
            case 's': flag_strict = true;   break;
            case 'n': flag_normal = true;   break;
            case 'r': flag_clear  = true;   break;
            case 'S': flag_status = true;   break;
            case 'v':
                printf("NetGuard v%s\n", NETGUARD_VERSION);
                return 0;
            case 'h':
            default:
                print_usage(argv[0]);
                return (opt == 'h') ? 0 : 1;
        }
    }

    /* ── Load configuration ───────────────────────────────────────── */

    if (config_load(&g_config, config_path) != NG_SUCCESS) {
        fprintf(stderr, "Failed to load configuration.\n");
        return 1;
    }

    /* ── Initialize logger ────────────────────────────────────────── */

    if (logger_init(g_config.log_file) != NG_SUCCESS) {
        fprintf(stderr, "Warning: logging unavailable.\n");
    }

    logger_log(LOG_INFO, NULL, 0, "NetGuard v%s starting", NETGUARD_VERSION);

    /* ── Initialize firewall backend ──────────────────────────────── */

    if (firewall_init() != NG_SUCCESS) {
        fprintf(stderr, "Firewall initialization failed. Are you root?\n");
        logger_close();
        return 1;
    }

    /* ── Handle non-interactive flags ─────────────────────────────── */

    if (flag_clear) {
        firewall_clear_rules();
        logger_close();
        return 0;
    }

    if (flag_strict) {
        g_config.mode = MODE_STRICT;
        config_save(&g_config);
    } else if (flag_normal) {
        g_config.mode = MODE_NORMAL;
        config_save(&g_config);
    }

    if (flag_apply || flag_strict || flag_normal) {
        int rc = firewall_apply_rules(&g_config);
        logger_close();
        return (rc == NG_SUCCESS) ? 0 : 1;
    }

    if (flag_status) {
        print_banner();
        config_print(&g_config);
        firewall_show_rules();
        action_check_network();
        logger_close();
        return 0;
    }

    /* ── Interactive mode ─────────────────────────────────────────── */

    setup_signals();
    print_banner();

    /* Perform initial network check */
    auto_network_check();

    while (g_running) {
        print_menu();

        char input[16];
        if (!read_line(input, sizeof(input)))
            break;

        /* Parse choice as integer */
        char *endptr = NULL;
        long choice = strtol(input, &endptr, 10);
        if (endptr == input || *endptr != '\0') {
            printf("  Invalid input. Enter a number 0–10.\n\n");
            continue;
        }

        printf("\n");

        switch (choice) {
            case 1:  action_add_trusted();   break;
            case 2:  action_remove_trusted(); break;
            case 3:  action_show_rules();     break;
            case 4:  action_enable_strict();  break;
            case 5:  action_enable_normal();  break;
            case 6:  action_apply_rules();    break;
            case 7:  action_clear_rules();    break;
            case 8:  action_check_network();  break;
            case 9:  action_export_logs();    break;
            case 10: config_print(&g_config); break;
            case 0:
                printf("  Shutting down NetGuard...\n");
                g_running = 0;
                break;
            default:
                printf("  Unknown option: %ld\n", choice);
                break;
        }
    }

    /* ── Cleanup ──────────────────────────────────────────────────── */

    logger_log(LOG_INFO, NULL, 0, "NetGuard shutting down");
    logger_close();

    printf("  NetGuard exited. Firewall rules remain active.\n");
    printf("  To clear rules: sudo netguard --clear\n\n");
    return 0;
}
