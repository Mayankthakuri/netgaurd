/*
 * logger.c - Logging subsystem implementation
 *
 * Writes structured log entries to a file with immediate flushing.
 * Each entry includes a timestamp, severity level, optional source IP
 * and port, and a human-readable message.
 *
 * Thread safety: This implementation uses a single FILE* and fflush()
 * after each write. For multi-threaded use, wrap calls with a mutex.
 */

#include "logger.h"
#include <stdarg.h>
#include <sys/stat.h>
#include <libgen.h>   /* dirname() */

/* ───────────────────────── State ────────────────────────────────────── */

static FILE *g_log_fp = NULL;
static char  g_log_path[MAX_PATH_LEN] = {0};

/* ───────────────────────── Helpers ──────────────────────────────────── */

/*
 * level_to_string - Convert a log_level_t to a fixed-width label string.
 */
static const char *level_to_string(log_level_t level)
{
    switch (level) {
        case LOG_INFO:    return "INFO   ";
        case LOG_WARN:    return "WARN   ";
        case LOG_ERROR:   return "ERROR  ";
        case LOG_DENIED:  return "DENIED ";
        case LOG_ALLOWED: return "ALLOWED";
        default:          return "UNKNOWN";
    }
}

/*
 * ensure_directory - Create parent directories for a file path.
 * Uses mkdir with mode 0750 (owner rwx, group rx).
 */
static void ensure_directory(const char *filepath)
{
    char tmp[MAX_PATH_LEN];
    snprintf(tmp, sizeof(tmp), "%s", filepath);

    /* dirname() may modify its argument, so we work on a copy */
    char *dir = dirname(tmp);
    if (dir && strcmp(dir, ".") != 0 && strcmp(dir, "/") != 0) {
        /* Simple recursive mkdir — works for one level deep */
        struct stat st;
        if (stat(dir, &st) != 0) {
            mkdir(dir, 0750);
        }
    }
}

/* ───────────────────────── Public API ───────────────────────────────── */

int logger_init(const char *log_path)
{
    if (!log_path || strlen(log_path) == 0)
        return NG_EINVAL;

    /* Close any previously opened log */
    logger_close();

    snprintf(g_log_path, MAX_PATH_LEN, "%s", log_path);
    ensure_directory(g_log_path);

    g_log_fp = fopen(g_log_path, "a");
    if (!g_log_fp) {
        fprintf(stderr, "[logger] Cannot open log file %s: %s\n",
                g_log_path, strerror(errno));
        return NG_ERROR;
    }

    /* Set restrictive permissions (owner read/write only) */
    chmod(g_log_path, 0600);

    /* Log startup */
    logger_log(LOG_INFO, NULL, 0, "NetGuard logger initialized");
    return NG_SUCCESS;
}

void logger_close(void)
{
    if (g_log_fp) {
        logger_log(LOG_INFO, NULL, 0, "NetGuard logger shutting down");
        fflush(g_log_fp);
        fclose(g_log_fp);
        g_log_fp = NULL;
    }
}

void logger_log(log_level_t level, const char *src_ip, int port,
                const char *fmt, ...)
{
    if (!g_log_fp || !fmt)
        return;

    /* Timestamp */
    time_t now = time(NULL);
    struct tm tm_buf;
    struct tm *tm_info = localtime_r(&now, &tm_buf);
    char timestamp[32];
    if (tm_info) {
        strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", tm_info);
    } else {
        snprintf(timestamp, sizeof(timestamp), "0000-00-00 00:00:00");
    }

    /* Format the user message */
    char msg[MAX_LOG_MSG_LEN];
    va_list args;
    va_start(args, fmt);
    vsnprintf(msg, sizeof(msg), fmt, args);
    va_end(args);

    /* Build the full log line */
    if (src_ip && port > 0) {
        fprintf(g_log_fp, "[%s] [%s] src=%s port=%d msg=%s\n",
                timestamp, level_to_string(level), src_ip, port, msg);
    } else if (src_ip) {
        fprintf(g_log_fp, "[%s] [%s] src=%s msg=%s\n",
                timestamp, level_to_string(level), src_ip, msg);
    } else {
        fprintf(g_log_fp, "[%s] [%s] msg=%s\n",
                timestamp, level_to_string(level), msg);
    }

    /* Flush immediately to avoid data loss on unexpected exit */
    fflush(g_log_fp);

    /* Also print errors and warnings to stderr for visibility */
    if (level == LOG_ERROR || level == LOG_WARN) {
        fprintf(stderr, "[netguard] [%s] %s\n", level_to_string(level), msg);
    }
}

int logger_export(const char *export_path)
{
    if (!export_path || strlen(export_path) == 0)
        return NG_EINVAL;

    if (strlen(g_log_path) == 0) {
        fprintf(stderr, "[logger] No log file configured\n");
        return NG_ERROR;
    }

    /* Flush current log before copying */
    if (g_log_fp)
        fflush(g_log_fp);

    /* Open source and destination */
    FILE *src = fopen(g_log_path, "r");
    if (!src) {
        fprintf(stderr, "[logger] Cannot read log %s: %s\n",
                g_log_path, strerror(errno));
        return NG_ERROR;
    }

    FILE *dst = fopen(export_path, "w");
    if (!dst) {
        fprintf(stderr, "[logger] Cannot write export %s: %s\n",
                export_path, strerror(errno));
        fclose(src);
        return NG_ERROR;
    }

    /* Copy in chunks */
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), src)) > 0) {
        if (fwrite(buf, 1, n, dst) != n) {
            fprintf(stderr, "[logger] Write error during export\n");
            fclose(src);
            fclose(dst);
            return NG_ERROR;
        }
    }

    fclose(src);
    if (fclose(dst) != 0) {
        fprintf(stderr, "[logger] Error closing export file\n");
        return NG_ERROR;
    }

    printf("[logger] Logs exported to %s\n", export_path);
    return NG_SUCCESS;
}
