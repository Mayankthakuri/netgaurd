/*
 * config.c - Configuration management implementation
 *
 * Parses a simple key=value config file. All input values are validated
 * before storage. The config file is fully rewritten on save to avoid
 * partial-write corruption.
 */

#include "config.h"
#include "utils.h"

/* ───────────────────────── Helper: trim whitespace ──────────────────── */

/*
 * trim_whitespace - Remove leading/trailing spaces and tabs in place.
 * Returns pointer into the original buffer (no allocation).
 */
static char *trim_whitespace(char *str)
{
    if (!str) return str;

    /* Leading */
    while (*str == ' ' || *str == '\t') str++;

    /* Trailing */
    size_t len = strlen(str);
    while (len > 0 && (str[len - 1] == ' '  || str[len - 1] == '\t' ||
                       str[len - 1] == '\n' || str[len - 1] == '\r')) {
        str[--len] = '\0';
    }
    return str;
}

/* ───────────────────────── Defaults ─────────────────────────────────── */

void config_set_defaults(netguard_config_t *cfg)
{
    if (!cfg) return;

    /* Zero the entire struct to ensure no garbage values */
    memset(cfg, 0, sizeof(*cfg));

    cfg->mode = MODE_NORMAL;
    snprintf(cfg->log_file, MAX_PATH_LEN, "./netguard.log");
    snprintf(cfg->config_path, MAX_PATH_LEN, "./netguard.conf");
    cfg->disable_mdns_on_untrusted = true;
}

/* ───────────────────────── Load ─────────────────────────────────────── */

int config_load(netguard_config_t *cfg, const char *path)
{
    if (!cfg || !path) return NG_EINVAL;

    config_set_defaults(cfg);
    snprintf(cfg->config_path, MAX_PATH_LEN, "%s", path);

    FILE *fp = fopen(path, "r");
    if (!fp) {
        if (errno == ENOENT) {
            fprintf(stderr, "[config] File not found: %s (using defaults)\n", path);
            return NG_SUCCESS;
        }
        fprintf(stderr, "[config] Cannot open %s: %s\n", path, strerror(errno));
        return NG_ERROR;
    }

    char line[MAX_LINE_LEN];
    int line_num = 0;

    while (fgets(line, sizeof(line), fp)) {
        line_num++;

        /* Strip trailing newline / carriage return */
        size_t len = strlen(line);
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r'))
            line[--len] = '\0';

        /* Skip blank lines and comments */
        char *trimmed = trim_whitespace(line);
        if (trimmed[0] == '#' || trimmed[0] == '\0')
            continue;

        /* Split on first '=' */
        char *eq = strchr(trimmed, '=');
        if (!eq) {
            fprintf(stderr, "[config] Line %d: missing '=', skipped\n", line_num);
            continue;
        }

        *eq = '\0';
        char *key   = trim_whitespace(trimmed);
        char *value  = trim_whitespace(eq + 1);

        /* ── Parse known keys ─────────────────────────────────────── */

        if (strcmp(key, "mode") == 0) {
            if (strcmp(value, "strict") == 0)
                cfg->mode = MODE_STRICT;
            else
                cfg->mode = MODE_NORMAL;

        } else if (strcmp(key, "log_file") == 0) {
            if (strlen(value) > 0 && strlen(value) < MAX_PATH_LEN)
                snprintf(cfg->log_file, MAX_PATH_LEN, "%s", value);

        } else if (strcmp(key, "trusted_ip") == 0) {
            if (config_add_trusted_ip(cfg, value) == NG_EINVAL)
                fprintf(stderr, "[config] Line %d: invalid IP '%s'\n",
                        line_num, value);

        } else if (strcmp(key, "protected_port") == 0) {
            char *endptr = NULL;
            long port = strtol(value, &endptr, 10);
            if (endptr == value || *endptr != '\0' || !utils_validate_port((int)port)) {
                fprintf(stderr, "[config] Line %d: invalid port '%s'\n",
                        line_num, value);
            } else if (cfg->protected_port_count < MAX_PROTECTED_PORTS) {
                cfg->protected_ports[cfg->protected_port_count++] = (int)port;
            }

        } else if (strcmp(key, "trusted_network") == 0) {
            if (strlen(value) > 0 && cfg->trusted_network_count < MAX_TRUSTED_NETS) {
                snprintf(cfg->trusted_networks[cfg->trusted_network_count],
                         MAX_SSID_LEN, "%s", value);
                cfg->trusted_network_count++;
            }

        } else if (strcmp(key, "disable_mdns_on_untrusted") == 0) {
            cfg->disable_mdns_on_untrusted = (strcmp(value, "yes") == 0 ||
                                               strcmp(value, "true") == 0 ||
                                               strcmp(value, "1") == 0);

        } else {
            fprintf(stderr, "[config] Line %d: unknown key '%s'\n",
                    line_num, key);
        }
    }

    fclose(fp);
    return NG_SUCCESS;
}

/* ───────────────────────── Save ─────────────────────────────────────── */

int config_save(const netguard_config_t *cfg)
{
    if (!cfg) return NG_EINVAL;

    FILE *fp = fopen(cfg->config_path, "w");
    if (!fp) {
        fprintf(stderr, "[config] Cannot write %s: %s\n",
                cfg->config_path, strerror(errno));
        return NG_ERROR;
    }

    fprintf(fp, "# NetGuard Configuration\n");
    fprintf(fp, "# Auto-generated — edit with care\n\n");

    fprintf(fp, "mode=%s\n", cfg->mode == MODE_STRICT ? "strict" : "normal");
    fprintf(fp, "log_file=%s\n", cfg->log_file);
    fprintf(fp, "disable_mdns_on_untrusted=%s\n",
            cfg->disable_mdns_on_untrusted ? "yes" : "no");

    fprintf(fp, "\n# Trusted IP addresses\n");
    for (int i = 0; i < cfg->trusted_ip_count; i++)
        fprintf(fp, "trusted_ip=%s\n", cfg->trusted_ips[i]);

    fprintf(fp, "\n# Protected ports\n");
    for (int i = 0; i < cfg->protected_port_count; i++)
        fprintf(fp, "protected_port=%d\n", cfg->protected_ports[i]);

    fprintf(fp, "\n# Trusted networks (SSID or gateway IP)\n");
    for (int i = 0; i < cfg->trusted_network_count; i++)
        fprintf(fp, "trusted_network=%s\n", cfg->trusted_networks[i]);

    if (fclose(fp) != 0) {
        fprintf(stderr, "[config] Error closing %s: %s\n",
                cfg->config_path, strerror(errno));
        return NG_ERROR;
    }

    return NG_SUCCESS;
}

/* ───────────────────────── Trusted IP Management ────────────────────── */

int config_add_trusted_ip(netguard_config_t *cfg, const char *ip)
{
    if (!cfg || !ip) return NG_EINVAL;

    /* Validate IP format using inet_pton via our utility */
    if (!utils_validate_ipv4(ip)) {
        fprintf(stderr, "[config] Invalid IPv4 address: %s\n", ip);
        return NG_EINVAL;
    }

    if (cfg->trusted_ip_count >= MAX_TRUSTED_IPS) {
        fprintf(stderr, "[config] Trusted IP list full (max %d)\n",
                MAX_TRUSTED_IPS);
        return NG_ERROR;
    }

    /* Check for duplicates — silently succeed */
    for (int i = 0; i < cfg->trusted_ip_count; i++) {
        if (strcmp(cfg->trusted_ips[i], ip) == 0)
            return NG_SUCCESS;
    }

    snprintf(cfg->trusted_ips[cfg->trusted_ip_count], MAX_IP_LEN, "%s", ip);
    cfg->trusted_ip_count++;
    return NG_SUCCESS;
}

int config_remove_trusted_ip(netguard_config_t *cfg, const char *ip)
{
    if (!cfg || !ip) return NG_EINVAL;

    for (int i = 0; i < cfg->trusted_ip_count; i++) {
        if (strcmp(cfg->trusted_ips[i], ip) == 0) {
            /* Shift remaining entries left to fill the gap */
            for (int j = i; j < cfg->trusted_ip_count - 1; j++)
                memcpy(cfg->trusted_ips[j], cfg->trusted_ips[j + 1], MAX_IP_LEN);

            /* Clear the last slot */
            memset(cfg->trusted_ips[cfg->trusted_ip_count - 1], 0, MAX_IP_LEN);
            cfg->trusted_ip_count--;
            return NG_SUCCESS;
        }
    }

    return NG_ENOTFOUND;
}

/* ───────────────────────── Print ────────────────────────────────────── */

void config_print(const netguard_config_t *cfg)
{
    if (!cfg) return;

    printf("\n");
    printf("╔══════════════════════════════════════════╗\n");
    printf("║        NetGuard Configuration            ║\n");
    printf("╠══════════════════════════════════════════╣\n");
    printf("║ Mode      : %-28s ║\n",
           cfg->mode == MODE_STRICT ? "STRICT (localhost only)" : "NORMAL");
    printf("║ Log file  : %-28s ║\n", cfg->log_file);
    printf("║ mDNS block: %-28s ║\n",
           cfg->disable_mdns_on_untrusted ? "yes (on untrusted)" : "no");
    printf("╠══════════════════════════════════════════╣\n");

    printf("║ Trusted IPs (%d):                         \n", cfg->trusted_ip_count);
    if (cfg->trusted_ip_count == 0) {
        printf("║   (none)                                 \n");
    } else {
        for (int i = 0; i < cfg->trusted_ip_count; i++)
            printf("║   %d. %-35s \n", i + 1, cfg->trusted_ips[i]);
    }

    printf("║ Protected Ports (%d):                     \n", cfg->protected_port_count);
    if (cfg->protected_port_count == 0) {
        printf("║   (none)                                 \n");
    } else {
        for (int i = 0; i < cfg->protected_port_count; i++)
            printf("║   %d. %-35d \n", i + 1, cfg->protected_ports[i]);
    }

    printf("║ Trusted Networks (%d):                    \n", cfg->trusted_network_count);
    if (cfg->trusted_network_count == 0) {
        printf("║   (none)                                 \n");
    } else {
        for (int i = 0; i < cfg->trusted_network_count; i++)
            printf("║   %d. %-35s \n", i + 1, cfg->trusted_networks[i]);
    }

    printf("╚══════════════════════════════════════════╝\n\n");
}
