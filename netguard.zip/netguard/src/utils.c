/*
 * utils.c - Utility functions implementation
 *
 * Provides:
 *   - IP address validation (inet_pton-based)
 *   - Port number validation
 *   - WiFi SSID detection (platform-specific)
 *   - Trusted network detection
 *   - mDNS/Bonjour traffic blocking via firewall rules
 *   - Input sanitization (shell metacharacter stripping)
 *   - Privilege checking
 *   - Safe command execution wrapper
 */

#include "utils.h"
#include "logger.h"
#include <arpa/inet.h>
#include <unistd.h>
#include <ctype.h>

/* ───────────────────────── Input Validation ──────────────────────────── */

/*
 * utils_validate_ipv4 - Strict IPv4 validation using inet_pton.
 * Rejects empty strings, CIDR notation, and malformed addresses.
 * Returns true only for a valid dotted-quad IPv4 address.
 */
bool utils_validate_ipv4(const char *ip)
{
    if (!ip || strlen(ip) == 0 || strlen(ip) >= MAX_IP_LEN)
        return false;

    /* Reject CIDR notation (e.g. 192.168.1.0/24) */
    if (strchr(ip, '/') != NULL)
        return false;

    /* Reject any shell metacharacters as an extra safety layer */
    for (const char *p = ip; *p; p++) {
        if (!isdigit((unsigned char)*p) && *p != '.')
            return false;
    }

    /* Use inet_pton for authoritative validation */
    struct in_addr addr;
    return inet_pton(AF_INET, ip, &addr) == 1;
}

/*
 * utils_validate_port - Check that a port number is in the valid range.
 * Valid ports: 1 through 65535 (0 is reserved).
 */
bool utils_validate_port(int port)
{
    return (port >= 1 && port <= 65535);
}

/*
 * utils_sanitize_input - Strip shell-dangerous characters from user input.
 * Removes: ; | & ` $ ( ) { } < > \ " ' ! ~
 * Also enforces max_len by null-terminating early.
 */
void utils_sanitize_input(char *input, size_t max_len)
{
    if (!input) return;

    /* Enforce length limit */
    if (strlen(input) >= max_len)
        input[max_len - 1] = '\0';

    const char *dangerous = ";|&`$(){}<>\\\"'!~";
    size_t j = 0;

    for (size_t i = 0; input[i] != '\0'; i++) {
        /* Strip newlines and carriage returns too */
        if (input[i] == '\n' || input[i] == '\r')
            continue;

        /* Remove dangerous characters */
        if (strchr(dangerous, input[i]) != NULL)
            continue;

        input[j++] = input[i];
    }
    input[j] = '\0';
}

/* ───────────────────────── Privilege Check ───────────────────────────── */

/*
 * utils_check_root - Check if the process has root (euid 0) privileges.
 * Required for firewall management on both Linux and macOS.
 */
bool utils_check_root(void)
{
    return (geteuid() == 0);
}

/* ───────────────────────── Safe Command Execution ───────────────────── */

/*
 * utils_safe_system - Execute a pre-validated shell command.
 * Logs the command to the NetGuard log before execution.
 * Returns the exit status of the command (0 = success).
 *
 * WARNING: Only call this with commands built from validated inputs.
 * Never pass raw user input.
 */
int utils_safe_system(const char *cmd)
{
    if (!cmd || strlen(cmd) == 0)
        return -1;

    logger_log(LOG_INFO, NULL, 0, "exec: %s", cmd);

    int ret = system(cmd);
    if (ret != 0) {
        logger_log(LOG_WARN, NULL, 0, "Command exited with status %d: %s",
                   ret, cmd);
    }
    return ret;
}

/* ───────────────────────── Network Detection ────────────────────────── */

/*
 * utils_get_current_ssid - Retrieve the current WiFi network name (SSID).
 *
 * macOS: Uses the `networksetup` utility to query the airport interface.
 * Linux: Uses `iwgetid -r` which returns just the SSID string.
 *
 * Returns NG_SUCCESS if an SSID was found, NG_ERROR otherwise.
 */
int utils_get_current_ssid(char *buf, size_t buf_len)
{
    if (!buf || buf_len == 0) return NG_EINVAL;

    buf[0] = '\0';

#if PLATFORM_MACOS
    /*
     * On macOS, networksetup -getairportnetwork en0 returns:
     *   "Current Wi-Fi Network: MyNetwork"
     * We parse out the network name after the colon.
     */
    FILE *fp = popen(
        "/usr/sbin/networksetup -getairportnetwork en0 2>/dev/null", "r");
    if (!fp) return NG_ERROR;

    char line[MAX_LINE_LEN];
    if (fgets(line, sizeof(line), fp)) {
        /* Look for "Network: " prefix */
        char *colon = strchr(line, ':');
        if (colon) {
            colon++;  /* Skip ':' */
            while (*colon == ' ') colon++;  /* Skip spaces */

            /* Remove trailing newline */
            size_t len = strlen(colon);
            while (len > 0 && (colon[len-1] == '\n' || colon[len-1] == '\r'))
                colon[--len] = '\0';

            if (len > 0) {
                snprintf(buf, buf_len, "%s", colon);
                pclose(fp);
                return NG_SUCCESS;
            }
        }
    }
    pclose(fp);

#elif PLATFORM_LINUX
    /*
     * On Linux, `iwgetid -r` prints just the SSID on a single line.
     * Falls back to nmcli if iwgetid is not available.
     */
    FILE *fp = popen("iwgetid -r 2>/dev/null || "
                     "nmcli -t -f active,ssid dev wifi | "
                     "grep '^yes:' | cut -d: -f2 2>/dev/null", "r");
    if (!fp) return NG_ERROR;

    char line[MAX_LINE_LEN];
    if (fgets(line, sizeof(line), fp)) {
        size_t len = strlen(line);
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r'))
            line[--len] = '\0';

        if (len > 0) {
            snprintf(buf, buf_len, "%s", line);
            pclose(fp);
            return NG_SUCCESS;
        }
    }
    pclose(fp);
#endif

    return NG_ERROR;
}

/*
 * utils_is_trusted_network - Check if the current network is in the trusted list.
 *
 * Compares the current SSID against each entry in trusted_nets[].
 * A case-sensitive exact match is required.
 *
 * Returns true if the current network is trusted, false if untrusted or
 * if the SSID cannot be determined (fail-safe to untrusted).
 */
bool utils_is_trusted_network(const char trusted_nets[][MAX_SSID_LEN],
                              int count)
{
    if (!trusted_nets || count <= 0)
        return false;

    char ssid[MAX_SSID_LEN];
    if (utils_get_current_ssid(ssid, sizeof(ssid)) != NG_SUCCESS) {
        /* Cannot determine network — fail-safe to untrusted */
        return false;
    }

    for (int i = 0; i < count; i++) {
        if (strcmp(ssid, trusted_nets[i]) == 0) {
            return true;
        }
    }

    return false;
}

/* ───────────────────────── mDNS Control ─────────────────────────────── */

/*
 * mDNS/Bonjour blocking approach:
 *
 * Rather than stopping system services (which may require SIP changes on
 * macOS or break other functionality), we block mDNS traffic at the
 * firewall level by dropping inbound UDP packets on port 5353.
 *
 * This is:
 *   - Safe: does not modify system service state
 *   - Documented: rules are visible in firewall output
 *   - Reversible: removing the rule restores mDNS
 *   - Effective: prevents external devices from discovering local services
 */

int utils_disable_mdns(void)
{
    char cmd[MAX_CMD_LEN];

#if PLATFORM_MACOS
    /*
     * Write a single-rule anchor file and load it into a sub-anchor
     * "netguard/mdns" to keep it separate from main rules.
     */
    const char *mdns_rules = "/tmp/netguard_mdns_block.conf";
    FILE *fp = fopen(mdns_rules, "w");
    if (!fp) return NG_ERROR;

    fprintf(fp, "# NetGuard: Block mDNS/Bonjour discovery\n");
    fprintf(fp, "block in quick proto udp from any to any port 5353\n");
    fprintf(fp, "block out quick proto udp from any to any port 5353\n");
    fclose(fp);

    snprintf(cmd, sizeof(cmd),
             "/sbin/pfctl -a netguard/mdns -f %s 2>/dev/null", mdns_rules);
    if (utils_safe_system(cmd) != 0) {
        logger_log(LOG_ERROR, NULL, 0, "Failed to block mDNS via pfctl");
        return NG_ERROR;
    }

#elif PLATFORM_LINUX
    /* Drop inbound mDNS (avahi) traffic */
    snprintf(cmd, sizeof(cmd),
             "/sbin/iptables -A %s -p udp --dport 5353 -j DROP 2>/dev/null",
             NETGUARD_CHAIN);
    if (utils_safe_system(cmd) != 0) {
        logger_log(LOG_ERROR, NULL, 0, "Failed to block mDNS via iptables");
        return NG_ERROR;
    }
#endif

    logger_log(LOG_INFO, NULL, 0,
               "mDNS/Bonjour traffic blocked (UDP 5353)");
    printf("[netguard] mDNS/Bonjour discovery disabled.\n");
    return NG_SUCCESS;
}

int utils_enable_mdns(void)
{
    char cmd[MAX_CMD_LEN];

#if PLATFORM_MACOS
    snprintf(cmd, sizeof(cmd),
             "/sbin/pfctl -a netguard/mdns -F all 2>/dev/null");
    utils_safe_system(cmd);
    unlink("/tmp/netguard_mdns_block.conf");

#elif PLATFORM_LINUX
    /* Remove the mDNS DROP rule (if present) */
    snprintf(cmd, sizeof(cmd),
             "/sbin/iptables -D %s -p udp --dport 5353 -j DROP 2>/dev/null",
             NETGUARD_CHAIN);
    utils_safe_system(cmd);
#endif

    logger_log(LOG_INFO, NULL, 0,
               "mDNS/Bonjour traffic unblocked (UDP 5353)");
    printf("[netguard] mDNS/Bonjour discovery re-enabled.\n");
    return NG_SUCCESS;
}
