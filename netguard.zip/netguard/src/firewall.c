/*
 * firewall.c - OS firewall integration implementation
 *
 * Platform-specific firewall rule management:
 *   macOS : pfctl with a named anchor ("netguard")
 *   Linux : iptables with a custom chain ("NETGUARD")
 *
 * SECURITY NOTES:
 * - All IP addresses are validated via inet_pton() before use in commands.
 * - All port numbers are validated to be in range 1–65535.
 * - Commands are built with snprintf() from validated components only.
 * - No raw user input is ever passed directly to system().
 */

#include "firewall.h"
#include "logger.h"
#include "utils.h"
#include <sys/stat.h>
#include <unistd.h>

/* ───────────────────────── macOS (pfctl) Implementation ─────────────── */

#if PLATFORM_MACOS

/*
 * PFCTL ANCHOR APPROACH:
 *   1. Ensure "anchor \"netguard\"" exists in /etc/pf.conf
 *   2. Write rules to a temporary file
 *   3. Load rules: pfctl -a netguard -f <file>
 *   4. Enable pf:   pfctl -e
 *
 * Cleanup: pfctl -a netguard -F all
 */

#define PF_CONF         "/etc/pf.conf"
#define PF_CONF_BACKUP  "/etc/pf.conf.netguard.bak"
#define ANCHOR_LINE     "anchor \"netguard\""

/*
 * pf_ensure_anchor - Make sure our anchor is declared in /etc/pf.conf.
 * If not present, appends it and reloads the main ruleset.
 * Creates a backup of the original pf.conf before modifying.
 */
static int pf_ensure_anchor(void)
{
    FILE *fp = fopen(PF_CONF, "r");
    if (!fp) {
        logger_log(LOG_ERROR, NULL, 0, "Cannot read %s: %s",
                   PF_CONF, strerror(errno));
        return NG_ERROR;
    }

    /* Check if anchor is already present */
    char line[MAX_LINE_LEN];
    bool found = false;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, ANCHOR_LINE)) {
            found = true;
            break;
        }
    }
    fclose(fp);

    if (found) return NG_SUCCESS;

    /* Backup original pf.conf */
    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd), "/bin/cp %s %s", PF_CONF, PF_CONF_BACKUP);
    if (utils_safe_system(cmd) != 0) {
        logger_log(LOG_ERROR, NULL, 0, "Failed to backup %s", PF_CONF);
        return NG_ERROR;
    }
    logger_log(LOG_INFO, NULL, 0, "Backed up %s to %s", PF_CONF, PF_CONF_BACKUP);

    /* Append anchor declaration */
    fp = fopen(PF_CONF, "a");
    if (!fp) {
        logger_log(LOG_ERROR, NULL, 0, "Cannot write to %s", PF_CONF);
        return NG_ERROR;
    }
    fprintf(fp, "\n# NetGuard anchor — added by netguard\n");
    fprintf(fp, "%s\n", ANCHOR_LINE);
    fclose(fp);

    /* Reload main ruleset to pick up the new anchor */
    snprintf(cmd, sizeof(cmd), "/sbin/pfctl -f %s 2>/dev/null", PF_CONF);
    utils_safe_system(cmd);

    logger_log(LOG_INFO, NULL, 0, "Added anchor to %s", PF_CONF);
    return NG_SUCCESS;
}

/*
 * pf_write_rules - Generate PF rules and write to NETGUARD_RULES_TMP.
 */
static int pf_write_rules(const netguard_config_t *cfg)
{
    FILE *fp = fopen(NETGUARD_RULES_TMP, "w");
    if (!fp) {
        logger_log(LOG_ERROR, NULL, 0, "Cannot write rules to %s",
                   NETGUARD_RULES_TMP);
        return NG_ERROR;
    }

    fprintf(fp, "# NetGuard PF rules — auto-generated, do not edit\n");
    fprintf(fp, "# Mode: %s\n\n",
            cfg->mode == MODE_STRICT ? "strict" : "normal");

    if (cfg->protected_port_count == 0) {
        fprintf(fp, "# No protected ports configured\n");
        fclose(fp);
        return NG_SUCCESS;
    }

    /* Build port list string: {22, 80, 443} */
    char ports[MAX_CMD_LEN] = "{";
    for (int i = 0; i < cfg->protected_port_count; i++) {
        char tmp[16];
        snprintf(tmp, sizeof(tmp), "%s%d",
                 (i > 0) ? ", " : "", cfg->protected_ports[i]);
        strncat(ports, tmp, sizeof(ports) - strlen(ports) - 1);
    }
    strncat(ports, "}", sizeof(ports) - strlen(ports) - 1);

    if (cfg->mode == MODE_NORMAL) {
        /*
         * NORMAL MODE:
         *   1. Allow trusted IPs to protected ports
         *   2. Block everyone else on protected ports
         */
        for (int i = 0; i < cfg->trusted_ip_count; i++) {
            fprintf(fp, "pass in quick proto tcp from %s to any port %s\n",
                    cfg->trusted_ips[i], ports);
            fprintf(fp, "pass in quick proto udp from %s to any port %s\n",
                    cfg->trusted_ips[i], ports);
        }
    }
    /* In strict mode, no "pass" rules — everything gets blocked */

    /* Block mDNS if configured */
    if (cfg->disable_mdns_on_untrusted) {
        fprintf(fp, "\n# Block mDNS/Bonjour discovery (UDP 5353)\n");
        fprintf(fp, "block in quick proto udp from any to any port 5353\n");
    }

    /* Block all other inbound to protected ports (with logging) */
    fprintf(fp, "\n# Block untrusted inbound to protected ports\n");
    fprintf(fp, "block in log proto tcp from any to any port %s\n", ports);
    fprintf(fp, "block in log proto udp from any to any port %s\n", ports);

    fclose(fp);
    chmod(NETGUARD_RULES_TMP, 0600);
    return NG_SUCCESS;
}

int firewall_init(void)
{
    if (!utils_check_root()) {
        fprintf(stderr, "[firewall] Root privileges required for pfctl.\n");
        fprintf(stderr, "[firewall] Please run: sudo netguard\n");
        return NG_EPERM;
    }

    /* Enable pf if not already running */
    utils_safe_system("/sbin/pfctl -e 2>/dev/null");

    return pf_ensure_anchor();
}

int firewall_apply_rules(const netguard_config_t *cfg)
{
    if (!cfg) return NG_EINVAL;

    /* Write rules to temp file */
    if (pf_write_rules(cfg) != NG_SUCCESS)
        return NG_ERROR;

    /* Load rules into our anchor */
    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd),
             "/sbin/pfctl -a %s -f %s 2>/dev/null",
             NETGUARD_ANCHOR, NETGUARD_RULES_TMP);

    if (utils_safe_system(cmd) != 0) {
        logger_log(LOG_ERROR, NULL, 0, "Failed to load pfctl rules");
        return NG_ERROR;
    }

    logger_log(LOG_INFO, NULL, 0,
               "Firewall rules applied (mode=%s, trusted=%d, ports=%d)",
               cfg->mode == MODE_STRICT ? "strict" : "normal",
               cfg->trusted_ip_count, cfg->protected_port_count);

    printf("[firewall] Rules applied successfully via pfctl.\n");
    return NG_SUCCESS;
}

int firewall_clear_rules(void)
{
    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd),
             "/sbin/pfctl -a %s -F all 2>/dev/null", NETGUARD_ANCHOR);

    if (utils_safe_system(cmd) != 0) {
        logger_log(LOG_WARN, NULL, 0, "Failed to flush pfctl anchor");
        return NG_ERROR;
    }

    /* Remove temp file */
    unlink(NETGUARD_RULES_TMP);

    logger_log(LOG_INFO, NULL, 0, "All NetGuard firewall rules cleared");
    printf("[firewall] All NetGuard rules cleared.\n");
    return NG_SUCCESS;
}

int firewall_show_rules(void)
{
    printf("\n=== Active NetGuard PF Rules ===\n\n");

    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd),
             "/sbin/pfctl -a %s -sr 2>/dev/null", NETGUARD_ANCHOR);

    int ret = system(cmd);
    if (ret != 0) {
        printf("  (no rules loaded or permission denied)\n");
    }

    printf("\n================================\n");
    return NG_SUCCESS;
}

const char *firewall_backend_name(void)
{
    return "pfctl (macOS Packet Filter)";
}

#endif /* PLATFORM_MACOS */

/* ───────────────────────── Linux (iptables) Implementation ──────────── */

#if PLATFORM_LINUX

/*
 * IPTABLES CHAIN APPROACH:
 *   1. Create custom chain "NETGUARD"
 *   2. Insert jump to NETGUARD at top of INPUT chain
 *   3. Populate NETGUARD with allow/deny rules
 *   4. Default action in chain: RETURN (pass back to INPUT)
 *
 * Cleanup: iptables -F NETGUARD
 */

int firewall_init(void)
{
    if (!utils_check_root()) {
        fprintf(stderr, "[firewall] Root privileges required for iptables.\n");
        fprintf(stderr, "[firewall] Please run: sudo netguard\n");
        return NG_EPERM;
    }

    /* Create our chain (ignore error if it already exists) */
    utils_safe_system("/sbin/iptables -N " NETGUARD_CHAIN " 2>/dev/null");

    /* Ensure our chain is hooked into INPUT (check first, add if missing) */
    int rc = system("/sbin/iptables -C INPUT -j " NETGUARD_CHAIN " 2>/dev/null");
    if (rc != 0) {
        if (utils_safe_system("/sbin/iptables -I INPUT 1 -j " NETGUARD_CHAIN) != 0) {
            logger_log(LOG_ERROR, NULL, 0,
                       "Failed to hook NETGUARD chain into INPUT");
            return NG_ERROR;
        }
    }

    logger_log(LOG_INFO, NULL, 0, "iptables chain initialized");
    return NG_SUCCESS;
}

int firewall_apply_rules(const netguard_config_t *cfg)
{
    if (!cfg) return NG_EINVAL;

    char cmd[MAX_CMD_LEN];

    /* Flush existing rules in our chain */
    snprintf(cmd, sizeof(cmd), "/sbin/iptables -F %s", NETGUARD_CHAIN);
    utils_safe_system(cmd);

    /* Rule 1: Allow localhost (loopback) — always */
    snprintf(cmd, sizeof(cmd),
             "/sbin/iptables -A %s -i lo -j RETURN", NETGUARD_CHAIN);
    utils_safe_system(cmd);

    /* Rule 2: Allow established/related connections */
    snprintf(cmd, sizeof(cmd),
             "/sbin/iptables -A %s -m state --state ESTABLISHED,RELATED -j RETURN",
             NETGUARD_CHAIN);
    utils_safe_system(cmd);

    if (cfg->mode == MODE_NORMAL) {
        /* Rule 3: Allow trusted IPs to protected ports */
        for (int i = 0; i < cfg->trusted_ip_count; i++) {
            for (int p = 0; p < cfg->protected_port_count; p++) {
                snprintf(cmd, sizeof(cmd),
                         "/sbin/iptables -A %s -s %s -p tcp --dport %d -j RETURN",
                         NETGUARD_CHAIN,
                         cfg->trusted_ips[i],
                         cfg->protected_ports[p]);
                utils_safe_system(cmd);

                snprintf(cmd, sizeof(cmd),
                         "/sbin/iptables -A %s -s %s -p udp --dport %d -j RETURN",
                         NETGUARD_CHAIN,
                         cfg->trusted_ips[i],
                         cfg->protected_ports[p]);
                utils_safe_system(cmd);
            }
        }
    }

    /* Block mDNS if configured */
    if (cfg->disable_mdns_on_untrusted) {
        snprintf(cmd, sizeof(cmd),
                 "/sbin/iptables -A %s -p udp --dport 5353 -j DROP",
                 NETGUARD_CHAIN);
        utils_safe_system(cmd);

        logger_log(LOG_INFO, NULL, 0, "mDNS (UDP 5353) blocked");
    }

    /* Log and drop on protected ports */
    for (int p = 0; p < cfg->protected_port_count; p++) {
        /* LOG rule */
        snprintf(cmd, sizeof(cmd),
                 "/sbin/iptables -A %s -p tcp --dport %d "
                 "-j LOG --log-prefix \"[NETGUARD_DENY] \"",
                 NETGUARD_CHAIN, cfg->protected_ports[p]);
        utils_safe_system(cmd);

        /* DROP rule */
        snprintf(cmd, sizeof(cmd),
                 "/sbin/iptables -A %s -p tcp --dport %d -j DROP",
                 NETGUARD_CHAIN, cfg->protected_ports[p]);
        utils_safe_system(cmd);

        /* Same for UDP */
        snprintf(cmd, sizeof(cmd),
                 "/sbin/iptables -A %s -p udp --dport %d "
                 "-j LOG --log-prefix \"[NETGUARD_DENY] \"",
                 NETGUARD_CHAIN, cfg->protected_ports[p]);
        utils_safe_system(cmd);

        snprintf(cmd, sizeof(cmd),
                 "/sbin/iptables -A %s -p udp --dport %d -j DROP",
                 NETGUARD_CHAIN, cfg->protected_ports[p]);
        utils_safe_system(cmd);
    }

    /* Default: RETURN (don't interfere with non-protected traffic) */
    snprintf(cmd, sizeof(cmd),
             "/sbin/iptables -A %s -j RETURN", NETGUARD_CHAIN);
    utils_safe_system(cmd);

    logger_log(LOG_INFO, NULL, 0,
               "Firewall rules applied (mode=%s, trusted=%d, ports=%d)",
               cfg->mode == MODE_STRICT ? "strict" : "normal",
               cfg->trusted_ip_count, cfg->protected_port_count);

    printf("[firewall] Rules applied successfully via iptables.\n");
    return NG_SUCCESS;
}

int firewall_clear_rules(void)
{
    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd), "/sbin/iptables -F %s", NETGUARD_CHAIN);

    if (utils_safe_system(cmd) != 0) {
        logger_log(LOG_WARN, NULL, 0, "Failed to flush iptables chain");
        return NG_ERROR;
    }

    logger_log(LOG_INFO, NULL, 0, "All NetGuard firewall rules cleared");
    printf("[firewall] All NetGuard rules cleared.\n");
    return NG_SUCCESS;
}

int firewall_show_rules(void)
{
    printf("\n=== Active NetGuard iptables Rules ===\n\n");

    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd),
             "/sbin/iptables -L %s -n -v --line-numbers 2>/dev/null",
             NETGUARD_CHAIN);

    int ret = system(cmd);
    if (ret != 0) {
        printf("  (no rules loaded or permission denied)\n");
    }

    printf("\n======================================\n");
    return NG_SUCCESS;
}

const char *firewall_backend_name(void)
{
    return "iptables (Linux Netfilter)";
}

#endif /* PLATFORM_LINUX */
