/*
 * logger.h - Logging subsystem for NetGuard
 *
 * Provides timestamped logging of all connection events (allowed/denied),
 * rule changes, mode switches, and errors. Logs are written to a file
 * specified in the configuration.
 *
 * Log format: [YYYY-MM-DD HH:MM:SS] [LEVEL] src=IP port=PORT msg=REASON
 */

#ifndef LOGGER_H
#define LOGGER_H

#include "netguard.h"

/*
 * logger_init - Open the log file for appending.
 * Creates the file and parent directory if they don't exist.
 * Returns NG_SUCCESS or NG_ERROR.
 */
int logger_init(const char *log_path);

/*
 * logger_close - Flush and close the log file.
 * Safe to call even if logger was not initialized.
 */
void logger_close(void);

/*
 * logger_log - Write a structured log entry.
 *   level  - Severity / event type (LOG_INFO, LOG_DENIED, etc.)
 *   src_ip - Source IP address (may be NULL for non-connection events)
 *   port   - Destination port (0 if not applicable)
 *   fmt    - printf-style format string for the message
 *   ...    - Format arguments
 *
 * Each entry is flushed immediately to prevent data loss on crash.
 */
void logger_log(log_level_t level, const char *src_ip, int port,
                const char *fmt, ...);

/*
 * logger_export - Copy the current log file to an export path.
 * Returns NG_SUCCESS on success, NG_ERROR on failure.
 */
int logger_export(const char *export_path);

#endif /* LOGGER_H */
