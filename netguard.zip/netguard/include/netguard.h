/*
 * netguard.h - Common definitions for NetGuard
 *
 * NetGuard: Local Network Privacy Utility
 * A defensive tool that protects local services by binding them to localhost,
 * managing firewall rules for trusted device whitelisting, and logging all
 * connection events. Supports Linux (iptables) and macOS (pfctl).
 *
 * This file contains shared constants, types, enums, and return codes
 * used throughout the project.
 */

#ifndef NETGUARD_H
#define NETGUARD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <errno.h>

/* ───────────────────────── Platform Detection ───────────────────────── */

#if defined(__APPLE__) && defined(__MACH__)
    #define PLATFORM_MACOS 1
    #define PLATFORM_LINUX 0
#elif defined(__linux__)
    #define PLATFORM_MACOS 0
    #define PLATFORM_LINUX 1
#else
    #error "Unsupported platform. Only Linux and macOS are supported."
#endif

/* ───────────────────────── Limits & Constants ───────────────────────── */

#define NETGUARD_VERSION    "1.0.0"
#define MAX_TRUSTED_IPS     64      /* Maximum number of whitelisted IPs       */
#define MAX_PROTECTED_PORTS 32      /* Maximum number of protected ports       */
#define MAX_TRUSTED_NETS    16      /* Maximum number of trusted networks      */
#define MAX_IP_LEN          46      /* Max length of an IP string (IPv6 safe)  */
#define MAX_PATH_LEN        256     /* Max file path length                    */
#define MAX_LINE_LEN        512     /* Max config/log line length              */
#define MAX_CMD_LEN         2048    /* Max shell command buffer                */
#define MAX_SSID_LEN        64      /* Max WiFi SSID / network name length     */
#define MAX_LOG_MSG_LEN     512     /* Max log message length                  */

/* Firewall anchor/chain name used across platforms */
#define NETGUARD_CHAIN      "NETGUARD"
#define NETGUARD_ANCHOR     "netguard"

/* Temporary rule file written before loading into pfctl/iptables-restore */
#define NETGUARD_RULES_TMP  "/tmp/netguard_rules.conf"

/* ───────────────────────── Enumerations ─────────────────────────────── */

/*
 * Operation modes:
 *   MODE_NORMAL - Allow connections from trusted IPs, block the rest on
 *                 protected ports.
 *   MODE_STRICT - Localhost only; block ALL remote inbound on protected ports.
 */
typedef enum {
    MODE_NORMAL = 0,
    MODE_STRICT = 1
} netguard_mode_t;

/*
 * Log levels used by the logger subsystem:
 *   LOG_INFO    - Informational messages (rule changes, config reloads)
 *   LOG_WARN    - Warnings (non-fatal issues)
 *   LOG_ERROR   - Errors (failed operations)
 *   LOG_DENIED  - Connection denied events
 *   LOG_ALLOWED - Connection allowed events
 */
typedef enum {
    LOG_INFO    = 0,
    LOG_WARN    = 1,
    LOG_ERROR   = 2,
    LOG_DENIED  = 3,
    LOG_ALLOWED = 4
} log_level_t;

/* ───────────────────────── Return Codes ─────────────────────────────── */

#define NG_SUCCESS   0      /* Operation completed successfully */
#define NG_ERROR    -1      /* Generic error                    */
#define NG_EPERM    -2      /* Permission denied                */
#define NG_EINVAL   -3      /* Invalid argument / input         */
#define NG_ENOTFOUND -4     /* Item not found                   */

#endif /* NETGUARD_H */
