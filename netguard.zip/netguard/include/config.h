/*
 * config.h - Configuration management for NetGuard
 *
 * Handles loading, saving, and modifying the configuration file.
 * The config stores trusted IPs, protected ports, operation mode,
 * log file path, trusted network names, and mDNS preferences.
 *
 * Config file format is a simple key=value text file with '#' comments.
 */

#ifndef CONFIG_H
#define CONFIG_H

#include "netguard.h"

/* ───────────────────────── Configuration Struct ─────────────────────── */

typedef struct {
    netguard_mode_t mode;                                   /* Current operation mode    */
    char log_file[MAX_PATH_LEN];                            /* Path to log file          */
    char config_path[MAX_PATH_LEN];                         /* Path to this config file  */

    char trusted_ips[MAX_TRUSTED_IPS][MAX_IP_LEN];          /* Whitelisted IP addresses  */
    int  trusted_ip_count;

    int  protected_ports[MAX_PROTECTED_PORTS];              /* Ports to protect          */
    int  protected_port_count;

    char trusted_networks[MAX_TRUSTED_NETS][MAX_SSID_LEN];  /* Trusted network names     */
    int  trusted_network_count;

    bool disable_mdns_on_untrusted;                         /* Block mDNS on pub. nets   */
} netguard_config_t;

/* ───────────────────────── Functions ────────────────────────────────── */

/*
 * config_set_defaults - Fill config struct with safe default values.
 * Should be called before config_load() to ensure all fields are initialized.
 */
void config_set_defaults(netguard_config_t *cfg);

/*
 * config_load - Parse a config file and populate the config struct.
 * Returns NG_SUCCESS on success, NG_ERROR on read failure.
 * If the file doesn't exist, defaults are used and NG_SUCCESS is returned.
 */
int config_load(netguard_config_t *cfg, const char *path);

/*
 * config_save - Write the current configuration back to its file.
 * Overwrites the entire file with the current in-memory state.
 */
int config_save(const netguard_config_t *cfg);

/*
 * config_add_trusted_ip - Add an IP to the trusted whitelist.
 * Validates the IP format before adding. Rejects duplicates silently.
 * Returns NG_EINVAL if the IP is malformed, NG_ERROR if the list is full.
 */
int config_add_trusted_ip(netguard_config_t *cfg, const char *ip);

/*
 * config_remove_trusted_ip - Remove an IP from the trusted whitelist.
 * Returns NG_ENOTFOUND if the IP was not in the list.
 */
int config_remove_trusted_ip(netguard_config_t *cfg, const char *ip);

/*
 * config_print - Print the full configuration to stdout in a human-readable format.
 */
void config_print(const netguard_config_t *cfg);

#endif /* CONFIG_H */
