/*
 * firewall.h - OS firewall integration for NetGuard
 *
 * Provides a platform-agnostic interface for managing firewall rules.
 *   - macOS: Uses pfctl (Packet Filter) with a named anchor.
 *   - Linux: Uses iptables with a custom chain.
 *
 * All functions validate inputs before constructing shell commands
 * to prevent command injection attacks.
 */

#ifndef FIREWALL_H
#define FIREWALL_H

#include "netguard.h"
#include "config.h"

/*
 * firewall_init - Perform one-time setup for the firewall backend.
 * On macOS: ensures the "netguard" anchor is registered in pf.conf.
 * On Linux: creates the NETGUARD iptables chain and hooks it into INPUT.
 * Returns NG_SUCCESS or NG_EPERM if not running as root.
 */
int firewall_init(void);

/*
 * firewall_apply_rules - Generate and load firewall rules from config.
 * Builds rules based on the current mode (normal/strict), trusted IPs,
 * protected ports, and mDNS preferences. Replaces any existing NetGuard rules.
 * Returns NG_SUCCESS or NG_ERROR.
 */
int firewall_apply_rules(const netguard_config_t *cfg);

/*
 * firewall_clear_rules - Remove all NetGuard-managed firewall rules.
 * Flushes the chain/anchor but does not remove the chain/anchor itself.
 * Returns NG_SUCCESS or NG_ERROR.
 */
int firewall_clear_rules(void);

/*
 * firewall_show_rules - Print the currently active NetGuard rules to stdout.
 * Returns NG_SUCCESS or NG_ERROR.
 */
int firewall_show_rules(void);

/*
 * firewall_backend_name - Return a human-readable name of the active backend.
 * e.g. "pfctl (macOS)" or "iptables (Linux)".
 */
const char *firewall_backend_name(void);

#endif /* FIREWALL_H */
