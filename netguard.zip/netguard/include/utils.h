/*
 * utils.h - Utility functions for NetGuard
 *
 * Provides input validation, network environment detection, mDNS control,
 * privilege checking, and general helper functions used across the project.
 */

#ifndef UTILS_H
#define UTILS_H

#include "netguard.h"

/*
 * utils_validate_ipv4 - Validate that a string is a well-formed IPv4 address.
 * Uses inet_pton() for strict validation. Does NOT accept CIDR notation.
 */
bool utils_validate_ipv4(const char *ip);

/*
 * utils_validate_port - Validate that a port number is within the valid range.
 * Returns true for ports 1–65535.
 */
bool utils_validate_port(int port);

/*
 * utils_is_trusted_network - Detect whether the device is currently on a
 * trusted network by comparing the active SSID / gateway against the
 * provided list of trusted network identifiers.
 *
 * On macOS: reads SSID via system_profiler or networksetup.
 * On Linux: reads SSID via iwgetid or nmcli.
 *
 * Returns true if the current network matches any entry in trusted_nets[].
 */
bool utils_is_trusted_network(const char trusted_nets[][MAX_SSID_LEN],
                              int count);

/*
 * utils_get_current_ssid - Retrieve the current WiFi SSID into buf.
 * Returns NG_SUCCESS if an SSID was found, NG_ERROR otherwise.
 */
int utils_get_current_ssid(char *buf, size_t buf_len);

/*
 * utils_disable_mdns - Block mDNS/Bonjour traffic via firewall rules.
 * This blocks UDP port 5353 inbound to prevent local service discovery.
 * Documented and reversible with utils_enable_mdns().
 */
int utils_disable_mdns(void);

/*
 * utils_enable_mdns - Remove the mDNS blocking rule, re-enabling discovery.
 */
int utils_enable_mdns(void);

/*
 * utils_check_root - Check whether the process is running with root/sudo.
 * Returns true if euid == 0.
 */
bool utils_check_root(void);

/*
 * utils_sanitize_input - Strip dangerous characters from user input.
 * Removes shell metacharacters (;|&`$) and truncates to max_len.
 * Modifies the string in place.
 */
void utils_sanitize_input(char *input, size_t max_len);

/*
 * utils_safe_system - Execute a shell command that was built from validated
 * inputs. Logs the command before execution. Returns the exit status.
 */
int utils_safe_system(const char *cmd);

#endif /* UTILS_H */
